package main

var Version string
