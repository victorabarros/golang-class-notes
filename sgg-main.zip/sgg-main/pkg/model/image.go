package model

// Image holds the image representation
type Image struct {
	Path string
}
