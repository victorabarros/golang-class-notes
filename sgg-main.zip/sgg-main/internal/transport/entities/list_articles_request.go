package entities

type ListArticlesParams struct {
	WithImages string `json:"withImages"`
}
